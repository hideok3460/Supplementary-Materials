# Hardware Reproducibility Archive

This archive contains actual files exported from the executed same-backend
canonical/noncanonical CP-TNI experiment.

- Backend: `ibm_phoenix`
- IBM job ID: `daj7e68mhr3c73e8kotg`
- Circuits: 216
- Shots per circuit: 4096
- Total shots: 884736
- Receiver bit-string order: `q4 q3`
- Calibration snapshot: `2026-09-13T10:12:37.785962+00:00` (11.9 seconds before submission)
- Job submission: `2026-09-13T10:12:49.646084+00:00`

The `raw_counts/per_circuit` directory contains one JSON file for every circuit.
`hardware_final_layouts_all_circuits.csv` contains all 216 final layouts.
`hardware_backend_calibration_snapshot.json` is the contemporaneous saved snapshot.
Counts are unmitigated, and no SPAM separation was applied.

IBM job IDs are provenance identifiers and are not the sole data-access mechanism,
because the complete raw counts are included directly.
